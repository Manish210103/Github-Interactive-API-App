import { Component } from '@angular/core';
import { GithubService } from '../../services/github.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  username!: string;
  user: any;

  constructor(private githubService: GithubService) { }

  fetchUser() {
    this.githubService.getUserData(this.username).subscribe((data: any) => {
      this.user = data;
      console.log(data)
    });
  }
}