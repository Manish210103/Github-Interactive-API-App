import { Component } from '@angular/core';

@Component({
  selector: 'app-repos',
  standalone: true,
  imports: [],
  templateUrl: './repos.component.html',
  styleUrl: './repos.component.css'
})
export class ReposComponent {

}
