// environment.ts / environment.development.ts
export const environment = {
  production: false,
  firebase : {
    apiKey: "AIzaSyDtuPQMdwvkxeGUt0HhC23OjCMVzGNjHMw",
    authDomain: "task-4c537.firebaseapp.com",
    projectId: "task-4c537",
    storageBucket: "task-4c537.appspot.com",
    messagingSenderId: "334634695458",
    appId: "1:334634695458:web:050f61bd6bf852790cc37b"
  }
}
