// environment.ts / environment.development.ts
export const environment = {
production: true
};
